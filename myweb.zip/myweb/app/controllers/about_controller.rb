class AboutController < ApplicationController
  def index
  end
  def book
  end
  def Home
  end
end
